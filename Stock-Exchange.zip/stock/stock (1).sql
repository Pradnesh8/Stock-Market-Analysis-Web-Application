-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 21, 2018 at 05:08 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stock`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertData` (IN `username` VARCHAR(20), IN `name` VARCHAR(20))  NO SQL
BEGIN
INSERT INTO test_store_procedure VALUES (username,name);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_user`
--

CREATE TABLE `admin_user` (
  `id` int(50) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone_number` varchar(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `date_of_birth` date NOT NULL,
  `password` varchar(50) NOT NULL,
  `access` varchar(10) NOT NULL DEFAULT 'disable'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_user`
--

INSERT INTO `admin_user` (`id`, `first_name`, `last_name`, `email`, `phone_number`, `gender`, `date_of_birth`, `password`, `access`) VALUES
(1, 'Pradnesh', 'Khedekar', 'khedekarprchit16e@student.mes.ac.in', '7738564198', 'male', '1998-12-08', '17f308e88a944f97b79b9df89f378370', 'enable'),
(3, 'Pradeep', 'Kshirsagar', 'kshirsagarppit1q6e@student.mes.ac.in', '7773332225', 'male', '2018-10-08', 'febc8f8ac083f5fc27e032c81e7b536a', 'enable'),
(4, 'ad', 'Asd', 'asdad@asd.com', '7773332225', 'male', '2018-10-02', '5f4dcc3b5aa765d61d8327deb882cf99', 'enable'),
(5, 'Adaas', 'Asasas', 'asdasds@das.cs', '7773332225', 'male', '2022-01-02', '5f4dcc3b5aa765d61d8327deb882cf99', 'enable'),
(6, 'Aniket', 'Gupta', 'guptaanr17des@student.mes.ac.in', '2313546488', 'male', '1999-08-12', '9dbbae8b0159030ac238af0985c3ad65', 'enable');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` longtext NOT NULL,
  `reply` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `phone`, `type`, `subject`, `message`, `reply`) VALUES
(1, 'fg', 'fgf', 'gfg', 'Complain', 'gfgfg', 'fgfgfgfgfg', 'we will work it out!!'),
(2, 'fg', 'fgf', 'gfg', 'Complain', 'gfgfg', 'fgfgfgfgfg', 'we will do it'),
(3, 'jhjh', 'hgh@fgfg.vfd', 'ghghg', 'Complain', 'sdsd', 'dsdsdsdsdsd', 'asssssdasd'),
(4, 'jhjh', 'hgh@fgfg.vfd', 'ghghg', 'Complain', 'sdsd', 'dsdsdsdsdsd', 'sdasdasd'),
(10, 'gfgfg', 'fgfgfg@fgfg.cvhg', 'asassssssss', 'Message', 'assssssssssssssss', 'sssssssssssssssssssssssssssssssssssssss', 'Well done'),
(13, 'asdasd', 'asdasd', 'adasd', 'Suggestion', 'asdasd', 'adasdasdasdasdad', 'asdasdcx'),
(14, 'asdasd', 'asdasd', 'adasd', 'Suggestion', 'asdasd', 'adasdasdasdasdad', 'asdacc'),
(15, 'Pradnesh', 'khedekarprchit16e@student.mes.ac.in', '7738564198', 'message', 'Feedback', 'This is best site I ever visited', 'Thank you!');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `headline` varchar(1000) NOT NULL,
  `detail` varchar(10000) NOT NULL,
  `image` varchar(100) NOT NULL,
  `source` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `headline`, `detail`, `image`, `source`) VALUES
(3, 'Petrol at Rs 87.50/litre, diesel Rs 77.37/litre in Mumbai', 'Petrol and diesel prices in Mumbai rose 21 paise and 31 paise on October 8 to Rs 87.50 and Rs 77.37 per litre, according to Indian Oil Corporation (IOC).\r\n\r\nDespite reducing value-added tax (VAT) by Rs 2.50 per litre, the financial capital is still the costliest for petrol. Delhi, which is yet to reduce VAT, is still the cheapest of all the metros and bulk of state capitals as it levies lower taxes.\r\n\r\nA litre of petrol and diesel in Delhi retails for Rs 82.03 and Rs 73.82 per litre after the respective hike of 21 paise and 29 paise. Kolkata too witnessed a similar price hike, with the motor fuel now retailing at Rs 83.87 and Rs 75.67 per litre, respectively.', 'petrol', 'https://www.moneycontrol.com/news/business/petrol-at-rs-87-50litre-diesel-rs-77-37litre-in-mumbai-3021701.html'),
(4, 'Artificial Intelligence may predict Alzheimer\'s five years in advance', 'Scientists -- including one of Indian origin -- have created an artificial intelligence (AI) algorithm that can accurately predict whether a person\'s cognitive decline will lead to Alzheimer\'s disease in the next five years.\r\n\r\nResearchers from the University of Toronto in Canada designed an algorithm that learns signatures from magnetic resonance imaging (MRI), genetics, and clinical data.\r\n\r\nAccording to the study published in PLOS Computational Biology, the algorithm can help predict whether an individual\'s cognitive faculties are likely to deteriorate towards Alzheimer\'s in the next five years', 'ai', 'https://www.moneycontrol.com/news/trends/health-trends/artificial-intelligence-may-predict-alzheimers-five-years-in-advance-3022441.html'),
(6, 'Top 10 short-term stock ideas which could give 5-28% returns', 'Nifty50 lost 5.6 percent, or over 600 points, for the week ended October 5 to record its biggest weekly loss in the last 26 weeks. The Nifty index has been making lower highs and lower lows on the weekly scale and has now fallen by around 1,500 points in the last 5 weeks.\r\n\r\nThe index formed a bearish candle on daily charts on Friday and on the weekly scale as well which suggests that bears are having a tight grip on the market.\r\n\r\nThe Nifty index broke below major levels like 61.80 percent retracement at 11,650, maximum Put OI congestion zones of 11,500-11,450, 50 Weekly EMA and is now gradually drifting lower with the higher pace of selling pressure, suggest experts.', 'stock', 'https://www.moneycontrol.com/news/business/markets/top-10-short-term-stock-ideas-which-could-give-5-28-returns-3020581.html'),
(7, 'Flipkart Big Billion Days sale to go live on Oct 9: Here are best festive offers', 'India\'s largest online retailer, Flipkart is just hours away from officially kick-starting its annual festive sale the Flipkart Big Billion Days for 2018. The sale will commence on October 10 and continue till October 14 for regular users. However, Flipkart Plus users will get three extra hours to shop with the sale starting for them at 9 pm on October 9.\r\n\r\nAs part of the sale, Flipkart will dish out offers on a whole host of products including smartphones, home appliances, heavy appliances, home decor, furniture, personal care appliances, smart devices, gadgets, and provide offers such as zero-interest EMIs, Flipkart Pay Later, cardless credit and EMIs on debit cards to its buyers.\r\n\r\nThe retailer has also partnered with HDFC Bank to roll out exclusive offers for buyers who use the bank’s debit or credit cards. Additionally, buyers using PhonePe for payment can avail 10 percent cashback during the sale.\r\n\r\nApart from mouth-watering discounts, Flipkart app users can win prizes including Google home, smartphones, televisions, Bluetooth speakers, headphones and Flipkart gift vouchers by participating in the Quiz to be hosted twice every day.', 'amitabh', 'https://www.moneycontrol.com/news/trends/current-affairs-trends/flipkart-big-billion-days-sale-to-go-live-on-oct-9-here-are-best-offers-in-flipkart-sale-3027741.html'),
(9, 'Stock market update: Over 330 stocks touch 52-week lows on NSE', 'NEW DELHI: Over 330 stocks, including Arvind, Bank of BarodaNSE -4.36 %, Bharti Airtel, Bombay Dyeing and CARE Ratings, hit 52-week lows on NSE in Tuesday\'s session. \r\n\r\nCentral Bank of India, Century Textiles & Industries, Concor, Dilip Buildcon, DHFL, Emami, Godrej Properties, Godrej Industries, Godrej Agrovet, Grasim Industries, InterGlobe Aviation, Maruti Suzuki India, United Spirits, Tata Chemicals, Tata Motors, Tata Power Company and Voltamp Transformers, too, featured among stocks that touched 52-week lows on NSE. ', 'NSE', 'https://economictimes.indiatimes.com/markets/stocks/news/stock-market-update-over-330-stocks-touch-52-week-lows-on-nse/articleshow/66131314.cms'),
(10, 'Titan, Aster DM among 15 stocks ready to rally, shows MACD ', 'NEW DELHI: A small pullback in the benchmark equity indices in Monday’s trade following three days of battering raised hopes of a possible recovery, but technical charts suggested it might just be a dead-cat bounce. \r\n\r\nAnalysts said any bounce at this stage may be shallow and traders must exercise caution. \r\nBut all is not that gloomy. ', 'bull', 'https://economictimes.indiatimes.com/markets/stocks/news/titan-aster-dm-among-15-stocks-ready-to-rally-shows-macd/articleshow/66129507.cms'),
(11, 'Stock market update: Nifty Bank index down; BoB, ICICI Bank, SBI weigh', 'NEW DELHI: Losses in shares of Bank of BarodaNSE -4.36 % (BoB) (down 3.13 per cent), IDFC Bank (down 1.48 per cent), ICICI Bank (down 1.14 per cent) and State Bank of IndiaNSE -1.05 % (SBI) (down 0.90 per cent) were weighing on bank index in Tuesday\'s session. \r\n\r\nThe Nifty Bank index was trading 0.12 per cent down at 24,590 around 01:35 pm. \r\n\r\nShares of Punjab National Bank (down 0.88 per cent), Federal Bank (down 0.28 per cent) and HDFC Bank (down 0.15 per cent) too were in the re .. ', 'man', 'https://economictimes.indiatimes.com/markets/stocks/news/stock-market-update-nifty-bank-index-down-bob-icici-bank-sbi-weigh/articleshow/66132508.cms'),
(13, 'Stockexchange hits 10m visitors', 'asdasdasdasdasdasd', 'Penguins', 'http://www.stockexchange.ml');

-- --------------------------------------------------------

--
-- Table structure for table `nse`
--

CREATE TABLE `nse` (
  `TICKER` varchar(10) DEFAULT NULL,
  `TYPE` varchar(12) DEFAULT NULL,
  `CURRENT` decimal(7,2) DEFAULT NULL,
  `OPEN` decimal(7,2) DEFAULT NULL,
  `HIGH` decimal(7,2) DEFAULT NULL,
  `LOW` decimal(7,2) DEFAULT NULL,
  `PREV CLOSE` decimal(7,2) DEFAULT NULL,
  `VOLUME` int(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nse`
--

INSERT INTO `nse` (`TICKER`, `TYPE`, `CURRENT`, `OPEN`, `HIGH`, `LOW`, `PREV CLOSE`, `VOLUME`) VALUES
('HCLTECH', 'NIFTY 50', '1074.80', '1070.00', '1084.55', '1048.00', '1084.00', 829329),
('AXISBANK', 'NIFTY 50', '555.55', '570.00', '574.50', '551.65', '568.50', 8578794),
('ZEEL', 'NIFTY 50', '414.75', '420.00', '422.35', '410.60', '422.30', 1390356),
('CIPLA', 'NIFTY 50', '635.60', '636.60', '642.65', '628.45', '636.65', 1083144),
('TCS', 'NIFTY 50', '2069.35', '2102.65', '2122.20', '2048.15', '2102.65', 1415271),
('WIPRO', 'NIFTY 50', '317.00', '321.40', '323.40', '312.70', '325.30', 2039157),
('INFY', 'NIFTY 50', '714.55', '725.05', '728.70', '710.00', '724.60', 4854216),
('GAIL', 'NIFTY 50', '341.00', '330.05', '345.40', '330.05', '332.05', 4248305),
('POWERGRID', 'NIFTY 50', '183.65', '186.50', '189.05', '182.50', '187.30', 1710189),
('NTPC', 'NIFTY 50', '160.70', '161.40', '164.35', '159.45', '162.90', 2737893),
('YESBANK', 'NIFTY 50', '216.50', '210.00', '226.60', '207.40', '206.00', 45491413),
('EICHERMOT', 'NIFTY 50', '21833.20', '21400.00', '22141.00', '20651.05', '21190.45', 113271),
('GRASIM', 'NIFTY 50', '911.80', '916.00', '924.80', '901.00', '922.75', 914406),
('ICICIBANK', 'NIFTY 50', '303.50', '307.30', '311.45', '301.50', '307.30', 14507853),
('LT', 'NIFTY 50', '1214.25', '1230.00', '1244.00', '1203.10', '1227.40', 2664145),
('BHARTIARTL', 'NIFTY 50', '295.15', '298.80', '298.80', '291.00', '298.60', 5436866),
('TECHM', 'NIFTY 50', '696.75', '714.50', '719.40', '694.30', '714.50', 1532989),
('INFRATEL', 'NIFTY 50', '264.20', '260.00', '266.95', '253.15', '260.20', 1668295),
('HDFCBANK', 'NIFTY 50', '1945.75', '1965.00', '1969.00', '1938.90', '1965.30', 3509547),
('TATASTEEL', 'NIFTY 50', '555.40', '567.00', '569.95', '547.10', '568.00', 6005836),
('MARUTI', 'NIFTY 50', '6837.95', '6915.00', '6989.00', '6774.25', '6904.35', 1139446),
('UPL', 'NIFTY 50', '612.20', '598.00', '625.00', '582.15', '596.65', 2636171),
('TATAMOTORS', 'NIFTY 50', '213.50', '217.80', '218.50', '212.25', '216.25', 7094268),
('HEROMOTOCO', 'NIFTY 50', '2848.35', '2725.00', '2860.00', '2710.05', '2740.75', 528655),
('TITAN', 'NIFTY 50', '799.15', '792.00', '806.00', '774.70', '792.10', 2839207),
('ITC', 'NIFTY 50', '270.60', '279.00', '279.40', '269.80', '276.50', 11451316),
('LUPIN', 'NIFTY 50', '845.00', '835.00', '848.20', '818.05', '838.75', 1390429),
('HINDUNILVR', 'NIFTY 50', '1562.60', '1551.00', '1570.40', '1537.10', '1558.55', 1116126),
('IOC', 'NIFTY 50', '122.65', '122.00', '125.70', '117.60', '118.05', 23290641),
('KOTAKBANK', 'NIFTY 50', '1090.15', '1050.05', '1097.50', '1044.15', '1052.20', 2671434),
('ADANIPORTS', 'NIFTY 50', '303.35', '301.80', '305.00', '294.10', '301.80', 3705005),
('BAJAJ-AUTO', 'NIFTY 50', '2558.45', '2526.05', '2588.25', '2501.25', '2543.05', 472279),
('RELIANCE', 'NIFTY 50', '1083.05', '1050.00', '1109.70', '1025.55', '1048.85', 19440047),
('COALINDIA', 'NIFTY 50', '265.80', '263.00', '272.95', '263.00', '263.00', 2637161),
('ASIANPAINT', 'NIFTY 50', '1238.65', '1210.00', '1247.80', '1201.10', '1209.50', 716464),
('HDFC', 'NIFTY 50', '1675.40', '1695.80', '1708.55', '1669.00', '1708.65', 3397138),
('ONGC', 'NIFTY 50', '146.80', '149.00', '150.85', '144.70', '147.05', 8689187),
('HINDPETRO', 'NIFTY 50', '173.40', '168.75', '180.65', '165.15', '165.10', 30075813),
('INDUSINDBK', 'NIFTY 50', '1597.60', '1606.00', '1629.40', '1590.05', '1607.35', 1614544),
('SBIN', 'NIFTY 50', '261.85', '259.75', '264.40', '258.35', '258.35', 13362510),
('DRREDDY', 'NIFTY 50', '2371.50', '2395.00', '2407.75', '2337.25', '2394.55', 317317),
('ULTRACEMCO', 'NIFTY 50', '3752.75', '3770.00', '3786.50', '3701.55', '3793.80', 284011),
('HINDALCO', 'NIFTY 50', '224.40', '235.00', '236.90', '222.55', '241.05', 16414097),
('VEDL', 'NIFTY 50', '216.55', '227.00', '228.25', '212.20', '231.65', 20810161),
('M&M', 'NIFTY 50', '769.65', '768.75', '780.95', '756.80', '769.55', 2751225),
('BPCL', 'NIFTY 50', '262.35', '273.00', '279.95', '257.05', '265.30', 19006166),
('SUNPHARMA', 'NIFTY 50', '602.85', '592.00', '608.75', '589.10', '597.95', 3040274),
('BAJAJFINSV', 'NIFTY 50', '5349.60', '5350.00', '5475.80', '5235.00', '5375.65', 173574),
('IBULHSGFIN', 'NIFTY 50', '935.05', '898.65', '955.00', '885.00', '911.70', 5732416),
('BAJFINANCE', 'NIFTY 50', '1987.75', '1992.00', '2090.00', '1950.00', '2023.30', 3774483),
('HCLTECH', 'NIFTY IT', '1074.80', '1070.00', '1084.55', '1048.00', '1084.00', 829329),
('KPIT', 'NIFTY IT', '191.30', '194.95', '197.65', '186.70', '195.70', 1912069),
('OFSS', 'NIFTY IT', '3933.80', '4044.60', '4044.60', '3907.00', '4019.90', 16709),
('TCS', 'NIFTY IT', '2069.35', '2102.65', '2122.20', '2048.15', '2102.65', 1415271),
('WIPRO', 'NIFTY IT', '317.00', '321.40', '323.40', '312.70', '325.30', 2039157),
('INFY', 'NIFTY IT', '714.55', '725.05', '728.70', '710.00', '724.60', 4854216),
('TECHM', 'NIFTY IT', '696.75', '714.50', '719.40', '694.30', '714.50', 1532989),
('INFIBEAM', 'NIFTY IT', '57.85', '62.00', '65.00', '57.35', '59.55', 25459398),
('TATAELXSI', 'NIFTY IT', '1130.00', '1145.10', '1163.60', '1062.00', '1138.15', 1201847),
('MINDTREE', 'NIFTY IT', '1003.80', '1032.00', '1049.65', '997.40', '1040.65', 694460),
('HEROMOTOCO', 'NIFTY AUTO', '2848.35', '2725.00', '2860.00', '2710.05', '2740.75', 528655),
('MOTHERSUMI', 'NIFTY AUTO', '230.65', '241.00', '241.00', '221.00', '240.70', 3953298),
('BOSCHLTD', 'NIFTY AUTO', '18500.00', '18800.00', '19139.75', '18400.00', '18813.90', 19808),
('MRF', 'NIFTY AUTO', '61000.00', '60711.00', '61751.00', '59601.00', '61022.20', 9715),
('AMARAJABAT', 'NIFTY AUTO', '722.20', '715.10', '729.45', '704.05', '719.35', 651873),
('EXIDEIND', 'NIFTY AUTO', '246.20', '245.00', '248.95', '240.80', '248.65', 1010024),
('BHARATFORG', 'NIFTY AUTO', '565.25', '575.00', '581.70', '560.00', '576.95', 1700670),
('TATAMOTORS', 'NIFTY AUTO', '213.50', '217.80', '218.50', '212.25', '216.25', 7094268),
('TATAMTRDVR', 'NIFTY AUTO', '115.50', '116.80', '118.35', '114.40', '117.35', 1355731),
('M&M', 'NIFTY AUTO', '769.65', '768.75', '780.95', '756.80', '769.55', 2751225),
('EICHERMOT', 'NIFTY AUTO', '21833.20', '21400.00', '22141.00', '20651.05', '21190.45', 113271),
('APOLLOTYRE', 'NIFTY AUTO', '204.45', '195.90', '205.40', '193.90', '198.00', 2381087),
('TVSMOTOR', 'NIFTY AUTO', '497.50', '495.00', '507.90', '478.70', '503.95', 2284152),
('BAJAJ-AUTO', 'NIFTY AUTO', '2558.45', '2526.05', '2588.25', '2501.25', '2543.05', 472279),
('MARUTI', 'NIFTY AUTO', '6837.95', '6915.00', '6989.00', '6774.25', '6904.35', 1139446),
('ASHOKLEY', 'NIFTY AUTO', '108.60', '107.75', '111.90', '104.10', '107.75', 18881139),
('DEN', 'NIFTY MEDIA', '62.15', '58.45', '64.90', '58.40', '57.95', 468403),
('NETWORK18', 'NIFTY MEDIA', '41.40', '42.10', '43.00', '41.25', '42.20', 350039),
('TVTODAY', 'NIFTY MEDIA', '388.00', '398.30', '402.00', '382.20', '400.75', 126425),
('JAGRAN', 'NIFTY MEDIA', '109.45', '113.00', '113.20', '109.30', '112.45', 50963),
('HATHWAY', 'NIFTY MEDIA', '25.75', '27.00', '27.00', '25.20', '26.50', 682849),
('UFO', 'NIFTY MEDIA', '286.00', '289.15', '293.80', '286.00', '289.50', 3661),
('EROSMEDIA', 'NIFTY MEDIA', '77.75', '78.10', '79.60', '77.50', '78.10', 285532),
('PVR', 'NIFTY MEDIA', '1165.25', '1168.00', '1187.25', '1098.90', '1168.30', 173855),
('ZEEMEDIA', 'NIFTY MEDIA', '22.70', '23.15', '23.30', '22.50', '22.85', 206575),
('DBCORP', 'NIFTY MEDIA', '198.50', '197.90', '200.00', '194.65', '195.85', 19319),
('TV18BRDCST', 'NIFTY MEDIA', '33.40', '33.40', '34.05', '32.15', '33.50', 4100532),
('SUNTV', 'NIFTY MEDIA', '608.50', '606.00', '627.70', '587.25', '610.55', 1325035),
('INOXLEISUR', 'NIFTY MEDIA', '198.00', '206.50', '218.00', '195.95', '211.55', 45434),
('ZEEL', 'NIFTY MEDIA', '414.75', '420.00', '422.35', '410.60', '422.30', 1390356),
('DISHTV', 'NIFTY MEDIA', '52.20', '50.55', '52.70', '48.80', '52.30', 3687861),
('DRREDDY', 'NIFTY PHARMA', '2371.50', '2395.00', '2407.75', '2337.25', '2394.55', 317317),
('CIPLA', 'NIFTY PHARMA', '635.60', '636.60', '642.65', '628.45', '636.65', 1083144),
('SUNPHARMA', 'NIFTY PHARMA', '602.85', '592.00', '608.75', '589.10', '597.95', 3040274),
('DIVISLAB', 'NIFTY PHARMA', '1274.00', '1273.90', '1294.70', '1259.15', '1281.65', 424914),
('CADILAHC', 'NIFTY PHARMA', '374.75', '375.00', '380.95', '370.80', '378.35', 1048086),
('BIOCON', 'NIFTY PHARMA', '589.60', '611.00', '612.60', '585.70', '611.95', 1719816),
('LUPIN', 'NIFTY PHARMA', '845.00', '835.00', '848.20', '818.05', '838.75', 1390429),
('AUROPHARMA', 'NIFTY PHARMA', '737.90', '739.75', '745.90', '719.05', '744.25', 1888057),
('GLENMARK', 'NIFTY PHARMA', '592.95', '585.20', '599.00', '574.25', '585.70', 524076),
('PEL', 'NIFTY PHARMA', '2194.95', '2215.00', '2296.00', '2152.00', '2216.05', 499811);

-- --------------------------------------------------------

--
-- Table structure for table `reg_user`
--

CREATE TABLE `reg_user` (
  `email` varchar(100) NOT NULL,
  `otp` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg_user`
--

INSERT INTO `reg_user` (`email`, `otp`) VALUES
('pradeep99909@gmail.com', 1958),
('kshirsagarppit16e@student.mes.ac.in', 9246),
('pasas@gmail.com', 7776),
('sdsd@fggf.vfg', 9514),
('ALSKALS@kas.cx', 7600),
('kshirsagarppita16e@student.mes.ac.in', 5206),
('kshirsagarppit1q6e@student.mes.ac.in', 7453),
('asdad@asd.com', 7844),
('asdasds@das.cs', 9960),
('guptaanr17des@student.mes.ac.in', 2230),
('pck08@gmail.com', 8952);

-- --------------------------------------------------------

--
-- Table structure for table `stock_main`
--

CREATE TABLE `stock_main` (
  `id` int(11) NOT NULL,
  `name` varchar(6) DEFAULT NULL,
  `current_value` float DEFAULT NULL,
  `prev_value` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stock_main`
--

INSERT INTO `stock_main` (`id`, `name`, `current_value`, `prev_value`) VALUES
(1, 'HSI', 27014.5, 26729.4),
(2, 'GOLD', 30648, 30325),
(3, 'DOW', 25900, 25885.9),
(4, 'DAX', 11922.5, 12032.3),
(5, 'CRUDE', 5000, 5075),
(6, 'DOLLAR', 72.64, 70.13);

-- --------------------------------------------------------

--
-- Table structure for table `stock_news`
--

CREATE TABLE `stock_news` (
  `id` int(11) NOT NULL,
  `headline` varchar(1000) NOT NULL,
  `detail` varchar(10000) NOT NULL,
  `image` varchar(100) NOT NULL,
  `source` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stock_nse`
--

CREATE TABLE `stock_nse` (
  `date` varchar(10) DEFAULT NULL,
  `price` decimal(7,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stock_nse`
--

INSERT INTO `stock_nse` (`date`, `price`) VALUES
('2017-09-06', '9929.90'),
('2017-09-07', '9934.80'),
('2017-09-08', '10006.05'),
('2017-09-09', '10006.05'),
('2017-09-10', '10006.05'),
('2017-09-11', '10093.05'),
('2017-09-12', '10079.30'),
('2017-09-13', '10086.60'),
('2017-09-14', '10085.40'),
('2017-09-15', '10153.10'),
('2017-09-16', '10153.10'),
('2017-09-17', '10153.10'),
('2017-09-18', '10147.55'),
('2017-09-19', '10141.15'),
('2017-09-20', '10121.90'),
('2017-09-21', '9964.40'),
('2017-09-22', '9872.60'),
('2017-09-23', '9872.60'),
('2017-09-24', '9872.60'),
('2017-09-25', '9871.50'),
('2017-09-26', '9735.75'),
('2017-09-27', '9768.95'),
('2017-09-28', '9788.60'),
('2017-09-29', '9859.50'),
('2017-09-30', '9859.50'),
('2017-10-01', '9859.50'),
('2017-10-02', '9859.50'),
('2017-10-03', '9914.90'),
('2017-10-04', '9888.70'),
('2017-10-05', '9979.70'),
('2017-10-06', '9988.75'),
('2017-10-07', '9988.75'),
('2017-10-08', '9988.75'),
('2017-10-09', '10016.95'),
('2017-10-10', '9984.80'),
('2017-10-11', '10096.40'),
('2017-10-12', '10167.45'),
('2017-10-13', '10230.85'),
('2017-10-14', '10230.85'),
('2017-10-15', '10230.85'),
('2017-10-16', '10234.45'),
('2017-10-17', '10234.45'),
('2017-10-18', '10146.55'),
('2017-10-19', '10146.55'),
('2017-10-20', '10184.85'),
('2017-10-21', '10184.85'),
('2017-10-22', '10184.85'),
('2017-10-23', '10207.70'),
('2017-10-24', '10295.35'),
('2017-10-25', '10343.80'),
('2017-10-26', '10323.05'),
('2017-10-27', '10363.65'),
('2017-10-28', '10363.65'),
('2017-10-29', '10363.65'),
('2017-10-30', '10335.30'),
('2017-10-31', '10440.50'),
('2017-11-01', '10423.80'),
('2017-11-02', '10452.50'),
('2017-11-03', '10451.80'),
('2017-11-04', '10451.80'),
('2017-11-05', '10451.80'),
('2017-11-06', '10350.15'),
('2017-11-07', '10303.15'),
('2017-11-08', '10308.95'),
('2017-11-09', '10321.75'),
('2017-11-10', '10224.95'),
('2017-11-11', '10224.95'),
('2017-11-12', '10224.95'),
('2017-11-13', '10186.60'),
('2017-11-14', '10118.05'),
('2017-11-15', '10214.75'),
('2017-11-16', '10283.60'),
('2017-11-17', '10298.75'),
('2017-11-18', '10298.75'),
('2017-11-19', '10298.75'),
('2017-11-20', '10326.90'),
('2017-11-21', '10342.30'),
('2017-11-22', '10348.75'),
('2017-11-23', '10389.70'),
('2017-11-24', '10399.55'),
('2017-11-25', '10399.55'),
('2017-11-26', '10399.55'),
('2017-11-27', '10370.25'),
('2017-11-28', '10361.30'),
('2017-11-29', '10226.55'),
('2017-11-30', '10121.80'),
('2017-12-01', '10127.75'),
('2017-12-02', '10127.75'),
('2017-12-03', '10127.75'),
('2017-12-04', '10118.25'),
('2017-12-05', '10044.10'),
('2017-12-06', '10166.70'),
('2017-12-07', '10265.65'),
('2017-12-08', '10322.25'),
('2017-12-09', '10322.25'),
('2017-12-10', '10322.25'),
('2017-12-11', '10240.15'),
('2017-12-12', '10192.95'),
('2017-12-13', '10252.10'),
('2017-12-14', '10333.25'),
('2017-12-15', '10388.75'),
('2017-12-16', '10388.75'),
('2017-12-17', '10388.75'),
('2017-12-18', '10463.20'),
('2017-12-19', '10444.20'),
('2017-12-20', '10440.30'),
('2017-12-21', '10493.00'),
('2017-12-22', '10531.50'),
('2017-12-23', '10531.50'),
('2017-12-24', '10531.50'),
('2017-12-25', '10531.50'),
('2017-12-26', '10490.75'),
('2017-12-27', '10477.90'),
('2017-12-28', '10530.70'),
('2017-12-29', '10435.55'),
('2017-12-30', '10435.55'),
('2017-12-31', '10435.55'),
('2018-01-01', '10442.20'),
('2018-01-02', '10443.20'),
('2018-01-03', '10504.80'),
('2018-01-04', '10558.85'),
('2018-01-05', '10623.60'),
('2018-01-06', '10623.60'),
('2018-01-07', '10623.60'),
('2018-01-08', '10637.00'),
('2018-01-09', '10632.20'),
('2018-01-10', '10651.20'),
('2018-01-11', '10681.25'),
('2018-01-12', '10741.55'),
('2018-01-13', '10741.55'),
('2018-01-14', '10741.55'),
('2018-01-15', '10700.45'),
('2018-01-16', '10788.55'),
('2018-01-17', '10817.00'),
('2018-01-18', '10894.70'),
('2018-01-19', '10966.20'),
('2018-01-20', '10966.20'),
('2018-01-21', '10966.20'),
('2018-01-22', '11083.70'),
('2018-01-23', '11086.00'),
('2018-01-24', '11069.65'),
('2018-01-25', '11130.40'),
('2018-01-26', '11130.40'),
('2018-01-27', '11130.40'),
('2018-01-28', '11130.40'),
('2018-01-29', '11049.65'),
('2018-01-30', '11027.70'),
('2018-01-31', '11016.90'),
('2018-02-01', '10760.60'),
('2018-02-02', '10666.55'),
('2018-02-03', '10666.55'),
('2018-02-04', '10666.55'),
('2018-02-05', '10498.25'),
('2018-02-06', '10476.70'),
('2018-02-07', '10576.85'),
('2018-02-08', '10454.95'),
('2018-02-09', '10539.75'),
('2018-02-10', '10539.75'),
('2018-02-11', '10539.75'),
('2018-02-12', '10500.90'),
('2018-02-13', '10500.90'),
('2018-02-14', '10545.50'),
('2018-02-15', '10452.30'),
('2018-02-16', '10378.40'),
('2018-02-17', '10378.40'),
('2018-02-18', '10378.40'),
('2018-02-19', '10360.40'),
('2018-02-20', '10397.45'),
('2018-02-21', '10382.70'),
('2018-02-22', '10491.05'),
('2018-02-23', '10582.60'),
('2018-02-24', '10582.60'),
('2018-02-25', '10582.60'),
('2018-02-26', '10554.30'),
('2018-02-27', '10492.85'),
('2018-02-28', '10458.35'),
('2018-03-01', '10358.85'),
('2018-03-02', '10358.85'),
('2018-03-03', '10358.85'),
('2018-03-04', '10358.85'),
('2018-03-05', '10249.25'),
('2018-03-06', '10154.20'),
('2018-03-07', '10242.65'),
('2018-03-08', '10226.85'),
('2018-03-09', '10421.40'),
('2018-03-10', '10421.40'),
('2018-03-11', '10421.40'),
('2018-03-12', '10426.85'),
('2018-03-13', '10410.90'),
('2018-03-14', '10360.15'),
('2018-03-15', '10195.15'),
('2018-03-16', '10094.25'),
('2018-03-17', '10094.25'),
('2018-03-18', '10094.25'),
('2018-03-19', '10124.35'),
('2018-03-20', '10155.25'),
('2018-03-21', '10114.75'),
('2018-03-22', '9998.05'),
('2018-03-23', '10130.65'),
('2018-03-24', '10130.65'),
('2018-03-25', '10130.65'),
('2018-03-26', '10184.15'),
('2018-03-27', '10113.70'),
('2018-03-28', '10211.80'),
('2018-03-29', '10211.80'),
('2018-03-30', '10211.80'),
('2018-03-31', '10211.80'),
('2018-04-01', '10211.80'),
('2018-04-02', '10245.00'),
('2018-04-03', '10128.40'),
('2018-04-04', '10325.15'),
('2018-04-05', '10331.60'),
('2018-04-06', '10379.35'),
('2018-04-07', '10379.35'),
('2018-04-08', '10379.35'),
('2018-04-09', '10402.25'),
('2018-04-10', '10417.15'),
('2018-04-11', '10458.65'),
('2018-04-12', '10480.60'),
('2018-04-13', '10528.35'),
('2018-04-14', '10528.35'),
('2018-04-15', '10528.35'),
('2018-04-16', '10548.70'),
('2018-04-17', '10526.20'),
('2018-04-18', '10526.20'),
('2018-04-19', '10564.05'),
('2018-04-20', '10584.70'),
('2018-04-21', '10584.70'),
('2018-04-22', '10584.70'),
('2018-04-23', '10614.35'),
('2018-04-24', '10570.55'),
('2018-04-25', '10617.80'),
('2018-04-26', '10692.30'),
('2018-04-27', '10739.35'),
('2018-04-28', '10739.35'),
('2018-04-29', '10739.35'),
('2018-04-30', '10718.05'),
('2018-05-01', '10718.05'),
('2018-05-02', '10679.65'),
('2018-05-03', '10618.25'),
('2018-05-04', '10715.50'),
('2018-05-05', '10715.50'),
('2018-05-06', '10715.50'),
('2018-05-07', '10717.80'),
('2018-05-08', '10741.70'),
('2018-05-09', '10716.55'),
('2018-05-10', '10806.50'),
('2018-05-11', '10806.60'),
('2018-05-12', '10806.60'),
('2018-05-13', '10806.60'),
('2018-05-14', '10801.85'),
('2018-05-15', '10741.10'),
('2018-05-16', '10682.70'),
('2018-05-17', '10596.40'),
('2018-05-18', '10516.70'),
('2018-05-19', '10516.70'),
('2018-05-20', '10516.70'),
('2018-05-21', '10536.70'),
('2018-05-22', '10430.35'),
('2018-05-23', '10513.85'),
('2018-05-24', '10605.15'),
('2018-05-25', '10688.65'),
('2018-05-26', '10688.65'),
('2018-05-27', '10688.65'),
('2018-05-28', '10633.30'),
('2018-05-29', '10614.35'),
('2018-05-30', '10736.15'),
('2018-05-31', '10696.20'),
('2018-06-01', '10628.50'),
('2018-06-02', '10628.50'),
('2018-06-03', '10628.50'),
('2018-06-04', '10593.15'),
('2018-06-05', '10684.65'),
('2018-06-06', '10768.35'),
('2018-06-07', '10767.65'),
('2018-06-08', '10786.95'),
('2018-06-09', '10786.95'),
('2018-06-10', '10786.95'),
('2018-06-11', '10842.85'),
('2018-06-12', '10856.70'),
('2018-06-13', '10808.05'),
('2018-06-14', '10817.70'),
('2018-06-15', '10799.85'),
('2018-06-16', '10799.85'),
('2018-06-17', '10799.85'),
('2018-06-18', '10710.45'),
('2018-06-19', '10772.05'),
('2018-06-20', '10741.10'),
('2018-06-21', '10821.85'),
('2018-06-22', '10762.45'),
('2018-06-23', '10762.45'),
('2018-06-24', '10762.45'),
('2018-06-25', '10769.15'),
('2018-06-26', '10671.40'),
('2018-06-27', '10589.10'),
('2018-06-28', '10714.30'),
('2018-06-29', '10657.30'),
('2018-06-30', '10657.30'),
('2018-07-01', '10657.30'),
('2018-07-02', '10699.90'),
('2018-07-03', '10769.90'),
('2018-07-04', '10749.75'),
('2018-07-05', '10772.65'),
('2018-07-06', '10852.90'),
('2018-07-07', '10852.90'),
('2018-07-08', '10852.90'),
('2018-07-09', '10947.25'),
('2018-07-10', '10948.30'),
('2018-07-11', '11023.20'),
('2018-07-12', '11018.90'),
('2018-07-13', '10936.85'),
('2018-07-14', '10936.85'),
('2018-07-15', '10936.85'),
('2018-07-16', '11008.05'),
('2018-07-17', '10980.45'),
('2018-07-18', '10957.10'),
('2018-07-19', '11010.20'),
('2018-07-20', '11084.75'),
('2018-07-21', '11084.75'),
('2018-07-22', '11084.75'),
('2018-07-23', '11134.30'),
('2018-07-24', '11132.00'),
('2018-07-25', '11167.30'),
('2018-07-26', '11278.35'),
('2018-07-27', '11319.55'),
('2018-07-28', '11319.55'),
('2018-07-29', '11319.55'),
('2018-07-30', '11356.50'),
('2018-07-31', '11346.20'),
('2018-08-01', '11244.70'),
('2018-08-02', '11360.80'),
('2018-08-03', '11387.10'),
('2018-08-04', '11387.10'),
('2018-08-05', '11387.10'),
('2018-08-06', '11389.45'),
('2018-08-07', '11450.00'),
('2018-08-08', '11470.70'),
('2018-08-09', '11429.50'),
('2018-08-10', '11355.75'),
('2018-08-11', '11355.75'),
('2018-08-12', '11355.75'),
('2018-08-13', '11435.10'),
('2018-08-14', '11385.05'),
('2018-08-15', '11385.05'),
('2018-08-16', '11470.75'),
('2018-08-17', '11551.75'),
('2018-08-18', '11551.75'),
('2018-08-19', '11551.75'),
('2018-08-20', '11570.90'),
('2018-08-21', '11582.75'),
('2018-08-22', '11582.75'),
('2018-08-23', '11557.10'),
('2018-08-24', '11691.95'),
('2018-08-25', '11691.95'),
('2018-08-26', '11691.95'),
('2018-08-27', '11738.50'),
('2018-08-28', '11691.90'),
('2018-08-29', '11676.80'),
('2018-08-30', '11680.50'),
('2018-08-31', '11582.35'),
('2018-09-01', '11582.35'),
('2018-09-02', '11582.35'),
('2018-09-03', '11520.30'),
('2018-09-04', '11476.95'),
('2018-09-05', '11536.90'),
('2018-09-06', '11589.10'),
('2018-09-07', '11438.10'),
('2018-09-08', '11438.10'),
('2018-09-09', '11438.10'),
('2018-09-10', '11287.50'),
('2018-09-11', '11369.90'),
('2018-09-12', '11515.20'),
('2018-09-13', '11515.20'),
('2018-09-14', '11377.75'),
('2018-09-15', '11377.75'),
('2018-09-16', '11377.75'),
('2018-09-17', '11278.90'),
('2018-09-18', '11234.35'),
('2018-09-19', '11143.10'),
('2018-09-20', '11143.10'),
('2018-09-21', '10967.40'),
('2018-09-22', '10967.40'),
('2018-09-23', '10967.40'),
('2018-09-24', '11067.45'),
('2018-09-25', '11053.80'),
('2018-09-26', '10977.55'),
('2018-09-27', '10930.45'),
('2018-09-28', '11008.30'),
('2018-09-29', '11008.30'),
('2018-09-30', '11008.30'),
('2018-10-01', '10858.25'),
('2018-10-02', '10858.25'),
('2018-10-03', '10599.25');

-- --------------------------------------------------------

--
-- Table structure for table `stock_user`
--

CREATE TABLE `stock_user` (
  `id` int(10) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `date_of_birth` date NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock_user`
--

INSERT INTO `stock_user` (`id`, `first_name`, `last_name`, `email`, `phone_number`, `gender`, `date_of_birth`, `password`) VALUES
(2, 'Pradeep', 'Kshirsagar', 'pradeep99909@gmail.com', '7575757757', 'Male', '2018-09-03', '71b3b26aaa319e0cdf6fdb8429c112b0'),
(4, 'Pradnesh', 'Khedekar', 'pck08@gmail.com', '7738564198', 'male', '1998-08-12', '17f308e88a944f97b79b9df89f378370');

-- --------------------------------------------------------

--
-- Table structure for table `test_store_procedure`
--

CREATE TABLE `test_store_procedure` (
  `username` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test_store_procedure`
--

INSERT INTO `test_store_procedure` (`username`, `name`) VALUES
('pradnesh', 'pradnesh'),
('pradeep', 'pradeep'),
('pracks', 'asasd'),
('asdad', 'ass'),
('asdadas', 'asdaf');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_user`
--
ALTER TABLE `admin_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock_main`
--
ALTER TABLE `stock_main`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock_user`
--
ALTER TABLE `stock_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_user`
--
ALTER TABLE `admin_user`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `stock_main`
--
ALTER TABLE `stock_main`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `stock_user`
--
ALTER TABLE `stock_user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
